// Copyright 2021 Michael Harwerth - miq1 AT gmx DOT de

#include <iostream>
#include <iomanip>
#include <regex>
#include <mutex>
#include "Logging.h"
#include "ModbusClientTCP.h"
#include "parseTarget.h"

using std::cout;
using std::endl;
using std::printf;
using std::hex;
using std::dec;
using std::mutex;
using std::lock_guard;

// Mutex to protect the sync flags
mutex flagLock;
// Flag to hold the main thread until the client has answered
bool gotIt = false;
// Flag to signal successful completion of a request
bool successful = false;

// Data structure for basic Smartdose data
struct SDbasic {
  uint16_t onState;
  uint16_t flags;
  struct {
    uint16_t hours;
    uint8_t minutes;
    uint8_t seconds;
  } uptime;
  struct {
    uint16_t hours;
    uint8_t minutes;
    uint8_t seconds;
  } statetime;
  struct {
    uint16_t hours;
    uint8_t minutes;
    uint8_t seconds;
  } ontime;
} basicData;

// Data structure for additional data on Gosund devices
struct SDadvanced {
  float accW;
  float factorV;
  float factorA;
  float factorW;
  float watts;
  float volts;
  float amps;
} advancedData;

// Commands understood
const char *cmds[] = { "INFO", "ON", "OFF", "DEFAULT", "EVERY", "RESET", "FACTOR", "_X_END" };
enum CMDS : uint8_t { INFO = 0, SW_ON, SW_OFF, DEFLT, EVRY, RST_CNT, FCTR, X_END };

// Define an onData handler function to receive the regular responses
// Arguments are Modbus server ID, the function code requested, the message data and length of it, 
// plus a user-supplied token to identify the causing request
void handleData(ModbusMessage response, uint32_t token) 
{
  uint16_t offs = 3;
  lock_guard<mutex> l(flagLock);
  if (token == 1) {
    offs = response.get(offs, basicData.onState);
    offs = response.get(offs, basicData.flags);
    offs = response.get(offs, basicData.uptime.hours);
    offs = response.get(offs, basicData.uptime.minutes);
    offs = response.get(offs, basicData.uptime.seconds);
    offs = response.get(offs, basicData.statetime.hours);
    offs = response.get(offs, basicData.statetime.minutes);
    offs = response.get(offs, basicData.statetime.seconds);
    offs = response.get(offs, basicData.ontime.hours);
    offs = response.get(offs, basicData.ontime.minutes);
    offs = response.get(offs, basicData.ontime.seconds);
  } else if (token == 2) {
    offs = response.get(offs, advancedData.accW);
    offs = response.get(offs, advancedData.factorV);
    offs = response.get(offs, advancedData.factorA);
    offs = response.get(offs, advancedData.factorW);
    offs = response.get(offs, advancedData.volts);
    offs = response.get(offs, advancedData.amps);
    offs = response.get(offs, advancedData.watts);
  } else if (token == 5) {
    offs = response.get(offs, basicData.flags);
  } else {
/*
    printf("Response: serverID=%d, FC=%d, Token=%08X, length=%d:\n", response.getServerID(), response.getFunctionCode(), token, response.size());
    HEXDUMP_N("Data", response.data(), response.size());
*/
  }
  
  gotIt = true;
  successful = true;
}

// Define an onError handler function to receive error responses
// Arguments are the error code returned and a user-supplied token to identify the causing request
void handleError(Error error, uint32_t token) 
{
  lock_guard<mutex> l(flagLock);
  // ModbusError wraps the error code and provides a readable error message for it
  ModbusError me(error);
  cout << "Error response: " << (int)me << " - " << (const char *)me << endl;
  gotIt = true;
  successful = false;
}

void usage(const char *msg) {
  cout << msg << endl;
  cout << "Usage: Smartdose host[:port[:serverID]]] [cmd [cmd_parms]]" << endl;
  cout << "  cmd: ";
  for (uint8_t c = 0; c < X_END; c++) {
    if (c) cout << " | ";
    cout << cmds[c];
  }
  cout << endl;
  cout << "  DEFAULT ON|OFF" << endl;
  cout << "  EVERY <seconds>" << endl;
  cout << "  FACTOR [V|A|W [<factor>]]" << endl;
}

// ============= main =============
int main(int argc, char **argv) {
  // Target host parameters
  IPAddress targetIP = NIL_ADDR;
  uint16_t targetPort = 502;
  uint8_t targetServer = 1;
  char buf[128];

  // Define a TCP client
  Client cl;
  cl.setNoDelay(true);

  // Check calling arguments.
  // Arg1 is mandatory, a host name or IP address, optionally followed by ":port number",
  // again optionally followed by ":server ID".
  if (argc < 2) {
    usage("At least one argument needed!\n");
    return -1;
  }

  if (int rc = parseTarget(argv[1], targetIP, targetPort, targetServer)) {
    usage("Target descriptor invalid!");
    return rc;
  }

  cout << "Using " << string(targetIP) << ":" << targetPort << ":" << (unsigned int)targetServer << endl;

  // Next shall be a command word. Omission is like INFO
  uint8_t cmd = X_END;
  if (argc > 2) {
    for (uint8_t c = INFO; c < X_END; c++) {
      if (strncasecmp(argv[2], cmds[c], strlen(cmds[c])) == 0) {
        cmd = c;
        break;
      }
    }
    if (cmd == X_END) {
      usage("Invalid command!");
      return -1;
    }
  } else {
    cmd = INFO;
  }
    
  // Define a Modbus client using the TCP client
  ModbusClientTCP MBclient(cl);

  // Set up ModbusTCP client.
  // - provide onData handler function
  MBclient.onDataHandler(&handleData);
  // - provide onError handler function
  MBclient.onErrorHandler(&handleError);
  // Set message timeout to 2000ms and interval between requests to the same host to 200ms
  MBclient.setTimeout(2000, 200);
  // Start ModbusTCP background task
  MBclient.begin();

  // Set Modbus TCP server address and port number
  MBclient.setTarget(targetIP, targetPort);

  switch (cmd) {
// --------- Get and print out state data ------------------
  case INFO:
  case EVRY:
    {
      unsigned int interval = 0;
      unsigned int loopCnt = 0;

      if (cmd == EVRY) {
        if (argc > 3) {
          interval = atoi(argv[3]);
        }
        if (interval == 0) {
          usage("EVERY needs an interval > 0s");
          return -1;
        }
      }

      do {
        // Issue a request
        uint16_t addr = 1;
        uint16_t words = 8;

        {
          lock_guard<mutex> fl(flagLock);
          gotIt = false; // force sync
          Error err = MBclient.addRequest(1, targetServer, READ_HOLD_REGISTER, addr, words);
          if (err!=SUCCESS) {
            ModbusError e(err);
            cout << "Error creating request:" << hex << (int)e << dec << " - " << (const char *)e << endl;
            gotIt = true; // sync
          }
        }
        // Loop to wait for the result
        while (!gotIt) { delay(500); }

        // Print out results
        if (loopCnt == 0) {
          if (basicData.flags & 0x8000) cout << "Gosund device ";
          if (basicData.flags & 0x4000) cout << "Telnet server ";
          if (basicData.flags & 0x2000) cout << "Modbus server ";
          if (basicData.flags & 0x0001) cout << "Default: ON" << endl;
          else                          cout << "Default: OFF" << endl;
        
          snprintf(buf, 128, "Running since %4u:%02u:%02u", 
                        (unsigned int)basicData.uptime.hours, 
                        (unsigned int)basicData.uptime.minutes, 
                        (unsigned int)basicData.uptime.seconds);
          cout << buf << endl;

          snprintf(buf, 128, "ON time       %4u:%02u:%02u", 
                        (unsigned int)basicData.ontime.hours, 
                        (unsigned int)basicData.ontime.minutes, 
                        (unsigned int)basicData.ontime.seconds);
          cout << buf << endl;

          snprintf(buf, 128, "%-3s (%3d) for %4u:%02u:%02u", 
                        (basicData.onState ? "ON" : "OFF"),
                        (unsigned int)basicData.onState,
                        (unsigned int)basicData.statetime.hours, 
                        (unsigned int)basicData.statetime.minutes, 
                        (unsigned int)basicData.statetime.seconds);
          cout << buf << endl;
        } else {
          if (loopCnt % 24 == 1) {
            snprintf(buf, 128, "Loop:   Run time     ON time  now      since        kWh           W           V           A");
            cout << buf << endl;
          }
          snprintf(buf, 128, "%4u: %4u:%02u:%02u  %4u:%02u:%02u  %-3s %4u:%02u:%02u ",
            loopCnt,
            (unsigned int)basicData.uptime.hours, 
            (unsigned int)basicData.uptime.minutes, 
            (unsigned int)basicData.uptime.seconds,
            (unsigned int)basicData.ontime.hours, 
            (unsigned int)basicData.ontime.minutes, 
            (unsigned int)basicData.ontime.seconds,
            (basicData.onState ? "ON" : "OFF"),
            (unsigned int)basicData.statetime.hours, 
            (unsigned int)basicData.statetime.minutes, 
            (unsigned int)basicData.statetime.seconds);
          cout << buf;
        }

        if (basicData.flags & 0x8000) {
          addr = 9; 
          words = 14;
          {
            lock_guard<mutex> fl(flagLock);
            gotIt = false; // force sync
            Error err = MBclient.addRequest(2, targetServer, READ_HOLD_REGISTER, addr, words);
            if (err!=SUCCESS) {
              ModbusError e(err);
              cout << "Error creating request:" << hex << (int)e << dec << " - " << (const char *)e << endl;
              gotIt = true; // sync
            }
          }
          // Loop to wait for the result
          while (!gotIt) { delay(500); }

          if (loopCnt == 0) {
            snprintf(buf, 128, "accumulated   %10.2f kWh", advancedData.accW / 1000.0);
            cout << buf << endl;
            snprintf(buf, 128, "Power         %10.2f W", advancedData.watts);
            cout << buf << endl;
            snprintf(buf, 128, "Voltage       %10.2f V", advancedData.volts);
            cout << buf << endl;
            snprintf(buf, 128, "Current       %10.2f A", advancedData.amps);
          } else {
            snprintf(buf, 128, "%10.2f  %10.2f  %10.2f  %10.2f",
              advancedData.accW / 1000.0,
              advancedData.watts,
              advancedData.volts,
              advancedData.amps);
          }
          cout << buf << endl;
        } else {
          if (interval) {
            cout << endl;
          }
        }
        sleep(interval);
        loopCnt++;
      } while (interval);
    }
    break;
// --------- Switch ON ------------------
  case SW_ON:
    {
      // Write 255 to addr 1
      uint16_t addr = 1;

      {
        lock_guard<mutex> fl(flagLock);
        gotIt = false; // force sync
        Error err = MBclient.addRequest(3, targetServer, WRITE_HOLD_REGISTER, addr, 255);
        if (err!=SUCCESS) {
          ModbusError e(err);
          cout << "Error creating request:" << hex << (int)e << dec << " - " << (const char *)e << endl;
          gotIt = true; // sync
        }
      }

      // Loop to wait for the result
      while (!gotIt) { delay(500); }
    }
    break;
// --------- Switch OFF ------------------
  case SW_OFF:
    {
      // Write 0 to addr 1
      uint16_t addr = 1;

      {
        lock_guard<mutex> fl(flagLock);
        gotIt = false; // force sync
        Error err = MBclient.addRequest(4, targetServer, WRITE_HOLD_REGISTER, addr, 0);
        if (err!=SUCCESS) {
          ModbusError e(err);
          cout << "Error creating request:" << hex << (int)e << dec << " - " << (const char *)e << endl;
          gotIt = true; // sync
        }
      }

      // Loop to wait for the result
      while (!gotIt) { delay(500); }
    }
    break;
// --------- Default switch state ------------------
  case DEFLT:
    {
      // Check state argument
      uint8_t onOff = 99;
      if (argc > 3) {
        if (strncasecmp(argv[3], "ON", 2) == 0) {
          onOff = 1;
        } else if (strncasecmp(argv[3], "OFF", 3) == 0) {
          onOff = 0;
        }
      } 
      if (onOff == 99) {
        usage("DEFAULT requires ON or OFF!");
        return -1;
      }
      
      // Read flag register
      uint16_t addr = 2;
      uint16_t words = 1;

      {
        lock_guard<mutex> fl(flagLock);
        gotIt = false; // force sync
        Error err = MBclient.addRequest(5, targetServer, READ_HOLD_REGISTER, addr, words);
        if (err!=SUCCESS) {
          ModbusError e(err);
          cout << "Error creating request:" << hex << (int)e << dec << " - " << (const char *)e << endl;
          gotIt = true; // sync
        }
      }

      // Loop to wait for the result
      while (!gotIt) { delay(500); }

      // Read current default
      // Do nothing if state matches command argument
      if (basicData.flags & 0x0001) {
        if (onOff == 1) onOff = 99;
      } else {
        if (onOff == 0) onOff = 99;
      }

      // Something to be done?
      if (onOff != 99) {
        // Yes. Write flag register
        basicData.flags &= 0xFFFE;
        basicData.flags |= onOff;

        {
          lock_guard<mutex> fl(flagLock);
          gotIt = false; // force sync
          Error err = MBclient.addRequest(6, targetServer, WRITE_HOLD_REGISTER, addr, basicData.flags);
          if (err!=SUCCESS) {
            ModbusError e(err);
            cout << "Error creating request:" << hex << (int)e << dec << " - " << (const char *)e << endl;
            gotIt = true; // sync
          }
        }

        // Loop to wait for the result
        while (!gotIt) { delay(500); }

        if (!successful) {
          cout << "DEFAULT " << (onOff ? "ON" : "OFF") << " was unsuccessful." << endl;
        }
      }
    }
    break;
// --------- Reset power counter ------------------
  case RST_CNT:
    {
      // Read flag register
      uint16_t addr = 2;
      uint16_t words = 1;

      {
        lock_guard<mutex> fl(flagLock);
        gotIt = false; // force sync
        Error err = MBclient.addRequest(5, targetServer, READ_HOLD_REGISTER, addr, words);
        if (err!=SUCCESS) {
          ModbusError e(err);
          cout << "Error creating request:" << hex << (int)e << dec << " - " << (const char *)e << endl;
          gotIt = true; // sync
        }
      }

      // Loop to wait for the result
      while (!gotIt) { delay(500); }

      if (!(basicData.flags & 0x8000)) {
        usage("RESET is only for Gosund devices!");
        return -1;
      }

      addr = 9;
      {
        lock_guard<mutex> fl(flagLock);
        gotIt = false; // force sync
        Error err = MBclient.addRequest(6, targetServer, WRITE_HOLD_REGISTER, addr, 0);
        if (err!=SUCCESS) {
          ModbusError e(err);
          cout << "Error creating request:" << hex << (int)e << dec << " - " << (const char *)e << endl;
          gotIt = true; // sync
        }
      }

      // Loop to wait for the result
      while (!gotIt) { delay(500); }

      if (!successful) {
        cout << "RESET was unsuccessful." << endl;
      }
    }
    break;
// --------- Adjust meter values ------------------
  case FCTR:
    {
      // Read flag register
      uint16_t addr = 2;
      uint16_t words = 1;

      {
        lock_guard<mutex> fl(flagLock);
        gotIt = false; // force sync
        Error err = MBclient.addRequest(5, targetServer, READ_HOLD_REGISTER, addr, words);
        if (err!=SUCCESS) {
          ModbusError e(err);
          cout << "Error creating request:" << hex << (int)e << dec << " - " << (const char *)e << endl;
          gotIt = true; // sync
        }
      }

      // Loop to wait for the result
      while (!gotIt) { delay(500); }

      if (!(basicData.flags & 0x8000)) {
        usage("FACTOR is only for Gosund devices!");
        return -1;
      }

      // Output only
      if (argc < 4) {
        addr = 9; 
        words = 14;
        {
          lock_guard<mutex> fl(flagLock);
          gotIt = false; // force sync
          Error err = MBclient.addRequest(2, targetServer, READ_HOLD_REGISTER, addr, words);
          if (err!=SUCCESS) {
            ModbusError e(err);
            cout << "Error creating request:" << hex << (int)e << dec << " - " << (const char *)e << endl;
            gotIt = true; // sync
          }
        }
        // Loop to wait for the result
        while (!gotIt) { delay(500); }

        cout << "Correction factors:" << endl;
        snprintf(buf, 128, "V: %10.5f", advancedData.factorV);
        cout << buf << endl;
        snprintf(buf, 128, "A: %10.5f", advancedData.factorA);
        cout << buf << endl;
        snprintf(buf, 128, "W: %10.5f", advancedData.factorW);
        cout << buf << endl;
        
        return 0;
      }
      
      uint8_t type = 99;
      switch (*argv[3]) {
      case 'V':
        type = 0;
        break;
      case 'A':
        type = 1;
        break;
      case 'W':
        type = 2;
        break;
      }
      if (type == 99) {
        usage("FACTOR needs a unit (V/A/W)!");
        return -1;
      }

      float f = 1.0;
      if (argc > 4) {
        f = atof(argv[4]);
      }

      ModbusMessage facMsg(targetServer, USER_DEFINED_43);
      facMsg.add(type, f);

      {
        lock_guard<mutex> fl(flagLock);
        gotIt = false; // force sync
        Error err = MBclient.addRequest(facMsg, (uint32_t)7);
        if (err!=SUCCESS) {
          ModbusError e(err);
          cout << "Error creating request:" << hex << (int)e << dec << " - " << (const char *)e << endl;
          gotIt = true; // sync
        }
      }
      // Loop to wait for the result
      while (!gotIt) { delay(500); }

    }
    break;
  default:
    usage("MAYNOTHAPPEN error?!?");
    return -2;
  }

  return 0;
}

